
public enum MetodoPagamento {
	CARTAODECREDITO, DINHEIRO, GRATIS;
}
