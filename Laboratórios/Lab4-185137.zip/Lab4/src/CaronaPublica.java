
public class CaronaPublica {

}
