
public class CaronaPrivada {

}
