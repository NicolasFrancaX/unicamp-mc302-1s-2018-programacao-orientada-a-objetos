
public class CaronaCaroneiro {

}
